package com.example.model;

import jakarta.persistence.*;

@Entity
@Table(name = "vehicles")
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "vehicle_type", nullable = false)
    private String type;

    @Column(name = "vehicle_name", nullable = false)
    private String name;

    @Column(name = "availability_status", nullable = false)
    private boolean available;

    @Column(name = "rental_price_per_day", nullable = false)
    private double pricePerDay;

    // Default constructor
    public Vehicle() {}

    // Constructor with parameters
    public Vehicle(String type, String name, boolean available, double pricePerDay) {
        this.type = type;
        this.name = name;
        this.available = available;
        this.pricePerDay = pricePerDay;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public double getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(double pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    // Optional: Override toString for better output readability
    @Override
    public String toString() {
        return "Vehicle{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", name='" + name + '\'' +
                ", available=" + available +
                ", pricePerDay=" + pricePerDay +
                '}';
    }
}

package com.example.model.Controller;

import com.example.model.Vehicle;
import com.example.model.VehicleDAO;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.StageStyle;

import java.util.Optional;

public class VehicleController {

    @FXML
    private Button vehiclesBtn;

    @FXML
    private Button rentalsBtn;

    @FXML
    private StackPane contentPane;

    @FXML
    private TableView<Vehicle> vehicleTable;

    @FXML
    private TableColumn<Vehicle, Long> idColumn;

    @FXML
    private TableColumn<Vehicle, String> nameColumn;

    @FXML
    private TableColumn<Vehicle, String> typeColumn;

    @FXML
    private TableColumn<Vehicle, Double> priceColumn;

    @FXML
    private TableColumn<Vehicle, Boolean> availableColumn;

    private VehicleDAO vehicleDAO = new VehicleDAO();

    @FXML
    public void initialize() {
        // Set up the columns in the TableView
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("pricePerDay"));
        availableColumn.setCellValueFactory(new PropertyValueFactory<>("available"));

        // Load data into the TableView
        loadVehicleData();
    }

    private void loadVehicleData() {
        vehicleTable.setItems(FXCollections.observableArrayList(vehicleDAO.getAllVehicles()));
    }

    @FXML
    private void showVehicles() {
        System.out.println("Vehicles button clicked");
        loadVehicleData();
    }

    @FXML
    private void showRentals() {
        System.out.println("Rentals button clicked");
        // Implement logic for showing rental records if needed
    }

    @FXML
    private void addVehicle() {
        Dialog<Vehicle> dialog = new Dialog<>();
        dialog.initStyle(StageStyle.UTILITY);
        dialog.setTitle("Add New Vehicle");

        ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        TextField nameField = new TextField();
        nameField.setPromptText("Vehicle Name");

        TextField typeField = new TextField();
        typeField.setPromptText("Vehicle Type");

        TextField priceField = new TextField();
        priceField.setPromptText("Price Per Day");

        CheckBox availableCheckBox = new CheckBox("Available");

        VBox content = new VBox(10);
        content.getChildren().addAll(
                new Label("Name:"), nameField,
                new Label("Type:"), typeField,
                new Label("Price Per Day:"), priceField,
                availableCheckBox
        );
        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType) {
                String name = nameField.getText();
                String type = typeField.getText();
                double price = Double.parseDouble(priceField.getText());
                boolean available = availableCheckBox.isSelected();

                return new Vehicle(type, name, available, price);
            }
            return null;
        });

        dialog.showAndWait().ifPresent(vehicle -> {
            vehicleDAO.saveVehicle(vehicle); // Save vehicle to the database
            loadVehicleData(); // Refresh the TableView
        });
    }

    @FXML
    private void updateVehicle() {
        Vehicle selectedVehicle = vehicleTable.getSelectionModel().getSelectedItem();
        if (selectedVehicle == null) {
            showAlert("No vehicle selected", "Please select a vehicle to update.");
            return;
        }

        Dialog<Vehicle> dialog = new Dialog<>();
        dialog.initStyle(StageStyle.UTILITY);
        dialog.setTitle("Update Vehicle");

        ButtonType updateButtonType = new ButtonType("Update", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(updateButtonType, ButtonType.CANCEL);

        TextField nameField = new TextField(selectedVehicle.getName());
        TextField typeField = new TextField(selectedVehicle.getType());
        TextField priceField = new TextField(String.valueOf(selectedVehicle.getPricePerDay()));
        CheckBox availableCheckBox = new CheckBox("Available");
        availableCheckBox.setSelected(selectedVehicle.isAvailable());

        VBox content = new VBox(10);
        content.getChildren().addAll(
                new Label("Name:"), nameField,
                new Label("Type:"), typeField,
                new Label("Price Per Day:"), priceField,
                availableCheckBox
        );
        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == updateButtonType) {
                selectedVehicle.setName(nameField.getText());
                selectedVehicle.setType(typeField.getText());
                selectedVehicle.setPricePerDay(Double.parseDouble(priceField.getText()));
                selectedVehicle.setAvailable(availableCheckBox.isSelected());
                return selectedVehicle;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(vehicle -> {
            vehicleDAO.updateVehicle(vehicle); // Update vehicle in the database
            loadVehicleData(); // Refresh the TableView
        });
    }

    @FXML
    private void deleteVehicle() {
        Vehicle selectedVehicle = vehicleTable.getSelectionModel().getSelectedItem();
        if (selectedVehicle == null) {
            showAlert("No vehicle selected", "Please select a vehicle to delete.");
            return;
        }

        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Delete Vehicle");
        confirmAlert.setHeaderText("Are you sure you want to delete this vehicle?");
        confirmAlert.setContentText(selectedVehicle.getName());

        Optional<ButtonType> result = confirmAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            vehicleDAO.deleteVehicle(selectedVehicle.getId()); // Delete vehicle from database
            loadVehicleData(); // Refresh the TableView
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

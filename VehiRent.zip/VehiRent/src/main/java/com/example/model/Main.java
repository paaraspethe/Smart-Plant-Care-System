package com.example.model;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/main.fxml"));
        primaryStage.setTitle("Vehicle Rental Management System");
        primaryStage.setScene(new Scene(root, 800, 600));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


//package com.example.model;
//
//import com.example.model.VehicleDAO;
//import com.example.model.Vehicle;
//
//public class Main {
//    public static void main(String[] args) {
//        VehicleDAO vehicleDAO = new VehicleDAO();
//
//        // Add a new vehicle
//        Vehicle vehicle = new Vehicle();
//        vehicle.setType("Car");             // Sets the type of the vehicle
//        vehicle.setName("Toyota Camry");     // Sets the name of the vehicle
//        vehicle.setAvailable(true);          // Sets availability status
//        vehicle.setPricePerDay(50.0);        // Sets the rental price per day
//
//        vehicleDAO.saveVehicle(vehicle);
//
//        // Retrieve and display vehicles
//        vehicleDAO.getAllVehicles().forEach(v -> System.out.println(v.getName()));
//
//        HibernateUtil.shutdown();
//    }
//}
/*package com.example;

import com.example.model.Vehicle;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        // Set up Hibernate configuration and session factory
        Configuration configuration = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Vehicle.class);
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Create a new vehicle (CREATE operation)
        Vehicle vehicle = new Vehicle("Car", "Toyota Corolla", true, 55.0);
        createVehicle(sessionFactory, vehicle);

        // Read a vehicle (READ operation)
        Vehicle readVehicle = getVehicleById(sessionFactory, vehicle.getId());
        System.out.println("Vehicle Retrieved: " + readVehicle);

        // Update vehicle details (UPDATE operation)
        readVehicle.setPricePerDay(60.0);
        updateVehicle(sessionFactory, readVehicle);

        // Delete the vehicle (DELETE operation)
        deleteVehicle(sessionFactory, readVehicle.getId());

        // Close the session factory
        sessionFactory.close();
    }

    public static void createVehicle(SessionFactory sessionFactory, Vehicle vehicle) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(vehicle);
            transaction.commit();
            System.out.println("Vehicle Created: " + vehicle);
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public static Vehicle getVehicleById(SessionFactory sessionFactory, Long id) {
        Session session = sessionFactory.openSession();
        Vehicle vehicle = null;
        try {
            vehicle = session.get(Vehicle.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return vehicle;
    }

    public static void updateVehicle(SessionFactory sessionFactory, Vehicle vehicle) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.update(vehicle);
            transaction.commit();
            System.out.println("Vehicle Updated: " + vehicle);
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public static void deleteVehicle(SessionFactory sessionFactory, Long id) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            Vehicle vehicle = session.get(Vehicle.class, id);
            if (vehicle != null) {
                session.delete(vehicle);
                transaction.commit();
                System.out.println("Vehicle Deleted: " + vehicle);
            } else {
                System.out.println("Vehicle with ID " + id + " not found.");
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
*/
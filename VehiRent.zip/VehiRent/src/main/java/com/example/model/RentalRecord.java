package com.example.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "rental_records")
public class RentalRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;

    @Column(name = "customer_name")
    private String customerName;

    @Temporal(TemporalType.DATE)
    private Date rentalDate;

    @Temporal(TemporalType.DATE)
    private Date returnDate;

    // Default constructor
    public RentalRecord() {}

    // Constructor with parameters
    public RentalRecord(Vehicle vehicle, String customerName, Date rentalDate, Date returnDate) {
        this.vehicle = vehicle;
        this.customerName = customerName;
        this.rentalDate = rentalDate;
        this.returnDate = returnDate;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Date getRentalDate() {
        return rentalDate;
    }

    public void setRentalDate(Date rentalDate) {
        this.rentalDate = rentalDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }
}

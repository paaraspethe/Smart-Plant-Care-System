package com.example.model.Controller;

import com.example.model.RentalRecord;
import com.example.model.Vehicle;
import com.example.model.VehicleDAO;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;

import java.time.LocalDate;
import java.util.List;

public class RentalController {

    @FXML
    private TableView<RentalRecord> rentalTable;  // Table for displaying rental records

    @FXML
    private TextField customerNameField;  // Field for customer's name

    @FXML
    private DatePicker rentalDateField;   // Field for rental start date

    @FXML
    private DatePicker returnDateField;   // Field for rental return date

    private VehicleDAO vehicleDAO = new VehicleDAO();  // DAO instance for database operations

    @FXML
    public void initialize() {
        // Load rental records into the table
        loadRentalRecords();
    }

    private void loadRentalRecords() {
        List<RentalRecord> rentals = vehicleDAO.getAllRentals(); // Assuming getAllRentals() exists in DAO
        rentalTable.setItems(FXCollections.observableArrayList(rentals));
    }

    @FXML
    private void addRental() {
        String customerName = customerNameField.getText();
        LocalDate rentalDate = rentalDateField.getValue();
        LocalDate returnDate = returnDateField.getValue();

        // Assuming that you select a vehicle from the vehicle list
        Vehicle selectedVehicle = getSelectedVehicle(); // Implement this method

        RentalRecord rental = new RentalRecord();
        rental.setCustomerName(customerName);
        rental.setRentalDate(java.sql.Date.valueOf(rentalDate));
        rental.setReturnDate(java.sql.Date.valueOf(returnDate));
        rental.setVehicle(selectedVehicle);

        vehicleDAO.saveRental(rental);  // Save new rental record
        loadRentalRecords();  // Refresh the table with new data
    }

    private Vehicle getSelectedVehicle() {
        // This method should retrieve a selected vehicle, e.g., through a UI element
        // Placeholder for demonstration
        return new Vehicle("Car", "Honda Civic", true, 45.0);
    }
}
